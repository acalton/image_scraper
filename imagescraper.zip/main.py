from selenium import webdriver
import time
from flask import Flask, render_template, request
app = Flask(__name__)


@app.route('/')
def home():
    return render_template("home.html")


# location of web driver:
DRIVER_PATH = 'C:\\Users\\Ash\\Documents\\chromedriver_win32\\chromedriver'
wd = webdriver.Chrome(executable_path=DRIVER_PATH)

# initially navigates to website:
wd.get('https://google.com')


def scroll_toward_end():
    """
    Allows for automated scrolling during search process.
    """
    wd.execute_script("window.scrollTo(0, document.body.scrollHeight);")
    time.sleep(1)


@app.route('/result')
def get_url():
    """
    Given a search query, performs a google images search and returns the url of the first
    eligible image.
    :return: one_result: url of valid image - displayed in /result
    """
    default = '0'
    search_query = request.args.get('search_query', default)

    num_images = 10  # num of urls to return - checks multiple until usable one found
    # results_list = []  # list to hold urls of found images
    # use results_list if requesting multiple urls
    one_result = None

    print(f"Searching for {search_query} image")

    # navigates to google images search results for the given search query
    wd.get(f"https://www.google.com/search?safe=off&site=&tbm=isch&source=hp&q="
           f"{search_query}&oq={search_query}&gs_l=img")

    # scrolls while picking up results
    scroll_toward_end()

    # img.Q4LuWd for locating thumbnails
    thumbnails_found = wd.find_elements_by_css_selector("img.Q4LuWd")

    for thumbnail in thumbnails_found[0:num_images]:
        # Try clicking on each thumbnail (only does this for as many images as requested)
        try:
            thumbnail.click()
        except Exception:
            print('ERROR: Cannot click on the image.')
            continue

        # get the image url
        urls_found = wd.find_elements_by_css_selector('img.n3VNCb')
        time.sleep(0.2)  # time between image selections

        # save path to image, if the path includes http
        for url in urls_found:
            if url.get_attribute('src') and 'http' in url.get_attribute('src'):
                one_result = url.get_attribute('src')
                # results_list.append(url.get_attribute('src'))

    return render_template("result.html", result=one_result)


if __name__ == '__main__':
    app.run()
